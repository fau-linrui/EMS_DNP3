/*
 * Copyright 2013-2020 Automatak, LLC
 *
 * Licensed to Green Energy Corp (www.greenenergycorp.com) and Automatak
 * LLC (www.automatak.com) under one or more contributor license agreements.
 * See the NOTICE file distributed with this work for additional information
 * regarding copyright ownership. Green Energy Corp and Automatak LLC license
 * this file to you under the Apache License, Version 2.0 (the "License"); you
 * may not use this file except in compliance with the License. You may obtain
 * a copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "APDUHeader.h"

namespace opendnp3
{

APDUHeader APDUHeader::SolicitedConfirm(uint8_t seq)
{
    return Confirm(seq, false);
}

APDUHeader APDUHeader::UnsolicitedConfirm(uint8_t seq)
{
    return Confirm(seq, true);
}

APDUHeader APDUHeader::Confirm(uint8_t seq, bool unsolicited)
{
    APDUHeader header;
    header.function = FunctionCode::CONFIRM;
    header.control = AppControlField(true, true, false, unsolicited, seq);
    return header;
}

} // namespace opendnp3
